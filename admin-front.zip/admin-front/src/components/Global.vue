<script>
let editserver = false
export default
{
// 编辑服务器信息时候的dialog,测试
  editserver
}
</script>
