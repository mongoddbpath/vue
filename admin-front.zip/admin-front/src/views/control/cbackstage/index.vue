<template>
  <d2-container-frame src="http://www.feifanwh.com"/>
</template>

<script>
export default {
  name: 'cstageback',
  data () {
    return {
      filename: __filename
    }
  }
}
</script>
