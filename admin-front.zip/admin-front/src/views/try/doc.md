在 `D2 Crud` 组件中传入 `pagination` 对象，即可开启分页。代码如下：
