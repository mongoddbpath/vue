<template>
  <d2-container-frame src="http://www.guangma168.com/e/chuangli/admin.php?bb8Yt=59wOY8mTdqXZRYk249RL"/>
</template>

<script>
export default {
  data () {
    return {
      filename: __filename
    }
  }
}
</script>
