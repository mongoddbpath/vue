<template>
  <d2-container-frame src="http://www.21cl.net/selectWords/"/>
</template>
